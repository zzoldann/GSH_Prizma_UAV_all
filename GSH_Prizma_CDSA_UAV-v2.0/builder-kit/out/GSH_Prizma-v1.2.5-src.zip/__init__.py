# GSH Prizma Gen3 CDSA UAV - core package (skeleton for v1.2.5)
__all__ = []
__version__ = "1.2.5"
