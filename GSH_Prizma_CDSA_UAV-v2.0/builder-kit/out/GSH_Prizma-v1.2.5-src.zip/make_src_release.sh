#!/usr/bin/env bash
set -euo pipefail
trap 'echo "[ERR] ${BASH_SOURCE[0]}:${LINENO} ${BASH_COMMAND}"; exit 1' ERR
VER=$(python3 - <<'PY'
import pathlib,re
p=pathlib.Path('src')/'gsh_prizma'/'__init__.py'
s=p.read_text(encoding='utf-8')
print(re.search(r"__version__\s*=\s*['\"](.+?)['\"]", s).group(1))
PY
)
NAME="GSH_Prizma-v$VER"
STAGE="builder-kit/.srcstage"; OUT="builder-kit/out"; rm -rf "$STAGE"; mkdir -p "$STAGE" "$OUT"
rsync -a --exclude '__pycache__' src "$STAGE/"
[ -d assets ] && rsync -a --exclude '__pycache__' assets "$STAGE/" || true
[ -d examples ] && rsync -a --exclude '__pycache__' examples "$STAGE/" || true
for f in README.md CHANGELOG.md LICENSE BUILD.md; do [ -f "$f" ] && install -m 0644 "$f" "$STAGE/$f" || true; done
install -d "$STAGE/builder-kit"
for f in builder-kit/gsh_prizma_gui.spec builder-kit/requirements.txt; do [ -f "$f" ] && install -m 0644 "$f" "$STAGE/$f" || true; done
for f in builder-kit/pack_deb.sh builder-kit/pack_rpm.sh builder-kit/smoke_test.sh builder-kit/make_src_release.sh; do [ -f "$f" ] && install -m 0755 "$f" "$STAGE/$f" || true; done
zip -qr "$OUT/${NAME}-src.zip" -j -0 "$STAGE/"* && (cd "$STAGE" && zip -qr "$PWD/$OUT/${NAME}-src.zip" .)
sha256sum "$OUT/${NAME}-src.zip" > "$OUT/SHA256SUMS_v$VER.txt"
echo "[OK] $OUT/${NAME}-src.zip"; echo "[OK] $OUT/SHA256SUMS_v$VER.txt"
