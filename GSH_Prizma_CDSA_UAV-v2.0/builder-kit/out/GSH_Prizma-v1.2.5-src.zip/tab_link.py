# -*- coding: utf-8 -*-
from PySide6 import QtWidgets, QtCore
import os
import sys
import json, pathlib

HELP_PATHS = [
    pathlib.Path("assets/help/help_ru.json"),
    pathlib.Path(__file__).resolve().parents[3] / "assets" / "help" / "help_ru.json"
]

def load_help():
    for p in HELP_PATHS:
        try:
            if p.is_file():
                with open(p, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass
    return {}

def apply_help(widget: QtWidgets.QWidget, meta: dict):
    if not meta:
        return
    if "tooltip" in meta:
        widget.setToolTip(meta["tooltip"])
    if "whats_this" in meta:
        widget.setWhatsThis(meta["whats_this"])

class LinkBudgetTab(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.helpmap = load_help()
        self._build_ui()

    def _build_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        form = QtWidgets.QFormLayout()

        # injected: X-axis toggles
        self.logx_cb=QtWidgets.QCheckBox(load_help_map().get('logx',{}).get('label','Логарифмическая ось X'))
        apply_help(self.logx_cb,'logx')
        self.plainx_cb=QtWidgets.QCheckBox(load_help_map().get('no_pow10_x',{}).get('label','Без степени по X'))
        apply_help(self.plainx_cb,'no_pow10_x')
        form.addRow('', self.logx_cb)
        form.addRow('', self.plainx_cb)
        def _reapply():
            try:
                ax=getattr(self,'ax',None) or (self.figure.gca() if hasattr(self,'figure') else None)
                if ax: _apply_xaxis_format(ax, self.logx_cb.isChecked(), self.plainx_cb.isChecked())
            except Exception: pass
            for m in ('refresh_plot','redraw','draw','update_plot'):
                if hasattr(self,m):
                    try: getattr(self,m)()
                    except Exception: pass
        self.logx_cb.toggled.connect(_reapply)
        self.plainx_cb.toggled.connect(_reapply)
        layout.addLayout(form)

        self.model = QtWidgets.QComboBox()
        self.model.addItems(["FSPL","Two-Ray","W-I","Hata","COST231","P.1812","P.452"])
        apply_help(self.model, self.helpmap.get("model")); form.addRow(self.helpmap.get("model",{}).get("label","Модель распространения"), self.model)

        self.env = QtWidgets.QComboBox()
        self.env.addItems(["Городская","Пригород","Село/Дерев","Равнинная","Лес","Холмистая","Горная","Море/Водоём","Река/Долина"])
        apply_help(self.env, self.helpmap.get("env")); form.addRow(self.helpmap.get("env",{}).get("label","Местность"), self.env)

        self.mod = QtWidgets.QComboBox()
        self.mod.addItems(["LoRa","FSK","OQPSK"])
        apply_help(self.mod, self.helpmap.get("mod")); form.addRow(self.helpmap.get("mod",{}).get("label","Модуляция"), self.mod)

        def spin(minv, maxv, step, dec=0):
            s = QtWidgets.QDoubleSpinBox()
            s.setRange(minv, maxv)
            s.setDecimals(dec)
            s.setSingleStep(step)
            s.setAlignment(QtCore.Qt.AlignRight)
            s.setMaximumWidth(160)
            return s

        self.f_mhz = spin(100, 6000, 1, 3)
        apply_help(self.f_mhz, self.helpmap.get("f_mhz")); form.addRow(self.helpmap.get("f_mhz",{}).get("label","Частота, МГц"), self.f_mhz)

        self.bw_mhz = spin(0.007, 20.0, 0.001, 3)
        apply_help(self.bw_mhz, self.helpmap.get("bw_mhz")); form.addRow(self.helpmap.get("bw_mhz",{}).get("label","Полоса, МГц"), self.bw_mhz)

        self.sf = QtWidgets.QSpinBox(); self.sf.setRange(6,12)
        apply_help(self.sf, self.helpmap.get("sf")); form.addRow(self.helpmap.get("sf",{}).get("label","Spreading Factor (SF)"), self.sf)

        self.cr = QtWidgets.QComboBox(); self.cr.addItems(["4/5","4/6","4/7","4/8"])
        apply_help(self.cr, self.helpmap.get("cr")); form.addRow(self.helpmap.get("cr",{}).get("label","Code Rate (CR)"), self.cr)

        self.rx_bw_hz = spin(1000, 50000000, 1000, 0)
        apply_help(self.rx_bw_hz, self.helpmap.get("rx_bw_hz")); form.addRow(self.helpmap.get("rx_bw_hz",{}).get("label","Полоса приёмника, Гц"), self.rx_bw_hz)

        self.p_tx_dbm = spin(-20, 36, 0.5, 1)
        apply_help(self.p_tx_dbm, self.helpmap.get("p_tx_dbm")); form.addRow(self.helpmap.get("p_tx_dbm",{}).get("label","P_TX, дБм"), self.p_tx_dbm)

        self.g_tx_dbi = spin(-5, 20, 0.5, 1)
        apply_help(self.g_tx_dbi, self.helpmap.get("g_tx_dbi")); form.addRow(self.helpmap.get("g_tx_dbi",{}).get("label","G_TX, dBi"), self.g_tx_dbi)

        self.g_rx_dbi = spin(-5, 20, 0.5, 1)
        apply_help(self.g_rx_dbi, self.helpmap.get("g_rx_dbi")); form.addRow(self.helpmap.get("g_rx_dbi",{}).get("label","G_RX, dBi"), self.g_rx_dbi)

        self.l_cable_tx_db = spin(0, 10, 0.1, 1)
        apply_help(self.l_cable_tx_db, self.helpmap.get("l_cable_tx_db")); form.addRow(self.helpmap.get("l_cable_tx_db",{}).get("label","Потери TX, дБ"), self.l_cable_tx_db)

        self.l_cable_rx_db = spin(0, 10, 0.1, 1)
        apply_help(self.l_cable_rx_db, self.helpmap.get("l_cable_rx_db")); form.addRow(self.helpmap.get("l_cable_rx_db",{}).get("label","Потери RX, дБ"), self.l_cable_rx_db)

        self.nf_rx_db = spin(0.1, 20, 0.1, 1)
        apply_help(self.nf_rx_db, self.helpmap.get("nf_rx_db")); form.addRow(self.helpmap.get("nf_rx_db",{}).get("label","NF, дБ"), self.nf_rx_db)

        self.h_tx_m = spin(0.1, 12000.0, 0.1, 2)
        apply_help(self.h_tx_m, self.helpmap.get("h_tx_m")); form.addRow(self.helpmap.get("h_tx_m",{}).get("label","h_TX (м)"), self.h_tx_m)

        self.h_rx_m = spin(0.1, 12000.0, 0.1, 2)
        apply_help(self.h_rx_m, self.helpmap.get("h_rx_m")); form.addRow(self.helpmap.get("h_rx_m",{}).get("label","h_RX (м)"), self.h_rx_m)

        self.h_roof_m = spin(0.0, 80.0, 0.5, 1)
        apply_help(self.h_roof_m, self.helpmap.get("h_roof_m")); form.addRow(self.helpmap.get("h_roof_m",{}).get("label","h_roof (м)"), self.h_roof_m)

        self.w_street_m = spin(0.0, 60.0, 0.5, 1)
        apply_help(self.w_street_m, self.helpmap.get("w_street_m")); form.addRow(self.helpmap.get("w_street_m",{}).get("label","W улицы (м)"), self.w_street_m)

        self.b_block_m = spin(0.0, 300.0, 1.0, 1)
        apply_help(self.b_block_m, self.helpmap.get("b_block_m")); form.addRow(self.helpmap.get("b_block_m",{}).get("label","B кварт (м)"), self.b_block_m)

        self.phi_deg = spin(0.0, 90.0, 1.0, 1)
        apply_help(self.phi_deg, self.helpmap.get("phi_deg")); form.addRow(self.helpmap.get("phi_deg",{}).get("label","φ улицы (°)"), self.phi_deg)

        self.delta_h_m = spin(0.0, 500.0, 1.0, 1)
        apply_help(self.delta_h_m, self.helpmap.get("delta_h_m")); form.addRow(self.helpmap.get("delta_h_m",{}).get("label","Δh рельефа (м)"), self.delta_h_m)

        self.sigma_db = spin(2.0, 12.0, 0.1, 1)
        apply_help(self.sigma_db, self.helpmap.get("sigma_db")); form.addRow(self.helpmap.get("sigma_db",{}).get("label","σ (логнорм), дБ"), self.sigma_db)

        self.fade_p_pct = spin(1.0, 50.0, 1.0, 0)
        apply_help(self.fade_p_pct, self.helpmap.get("fade_p_pct")); form.addRow(self.helpmap.get("fade_p_pct",{}).get("label","Fade p, %"), self.fade_p_pct)

        self.avail_at_d_km = spin(0.1, 3000.0, 0.1, 1)
        apply_help(self.avail_at_d_km, self.helpmap.get("avail_at_d_km")); form.addRow(self.helpmap.get("avail_at_d_km",{}).get("label","p@ (дист), км"), self.avail_at_d_km)

        self.dist_max_km = QtWidgets.QComboBox()
        self.dist_max_km.addItems([str(x) for x in [1,2,5,10,50,100,500,3000]])
        apply_help(self.dist_max_km, self.helpmap.get("dist_max_km")); form.addRow(self.helpmap.get("dist_max_km",{}).get("label","X-max, км"), self.dist_max_km)

        self.logx = QtWidgets.QCheckBox(self.helpmap.get("logx",{}).get("label","Логарифмическая ось X"))
        apply_help(self.logx, self.helpmap.get("logx")); form.addRow("", self.logx)

        self.x_plain_ticks = QtWidgets.QCheckBox(self.helpmap.get("x_plain_ticks",{}).get("label","Без степени по X"))
        apply_help(self.x_plain_ticks, self.helpmap.get("x_plain_ticks")); form.addRow("", self.x_plain_ticks)

        self.force_horizon = QtWidgets.QCheckBox(self.helpmap.get("force_horizon",{}).get("label","Игнорировать ниже горизонта"))
        apply_help(self.force_horizon, self.helpmap.get("force_horizon")); form.addRow("", self.force_horizon)

        btns = QtWidgets.QHBoxLayout()
        self.btn_save = QtWidgets.QPushButton("Сохранить проект")
        self.btn_open = QtWidgets.QPushButton("Открыть проект")
        btns.addStretch(1); btns.addWidget(self.btn_save); btns.addWidget(self.btn_open)
        layout.addLayout(btns)
        layout.addStretch(1)


def resource_path(*parts):
    base=getattr(sys,'_MEIPASS',os.getcwd())
    p=os.path.join(base,*parts)
    return p if os.path.exists(p) else os.path.join(os.getcwd(),*parts)

_HELP_MAP=None
def load_help_map():
    global _HELP_MAP
    if _HELP_MAP is None:
        try:
            with open(resource_path('assets','help','help_ru.json'),'r',encoding='utf-8') as f:
                _HELP_MAP=json.load(f)
        except Exception:
            _HELP_MAP={}
    return _HELP_MAP

def apply_help(w,key,default=None):
    h=load_help_map().get(key,{})
    if hasattr(w,'setToolTip') and 'tooltip' in h: w.setToolTip(h['tooltip'])
    if hasattr(w,'setWhatsThis') and 'whats_this' in h: w.setWhatsThis(h['whats_this'])
    if hasattr(w,'setPlaceholderText') and 'label' in h: w.setPlaceholderText(h.get('label', default or key))


def _apply_xaxis_format(ax, logx, no_pow10):
    try:
        ax.set_xscale('log' if logx else 'linear')
        if not logx and no_pow10:
            try:
                ax.get_xaxis().get_major_formatter().set_scientific(False)
                ax.ticklabel_format(style='plain', axis='x')
            except Exception:
                pass
        ax.figure.canvas.draw_idle()
    except Exception:
        pass
